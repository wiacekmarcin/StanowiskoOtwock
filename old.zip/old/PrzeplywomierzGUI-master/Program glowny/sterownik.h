#ifndef STEROWNIK_H
#define STEROWNIK_H


class Sterownik
{
public:
    Sterownik();

private:
    bool connected;

};

#endif // STEROWNIK_H
