#include "sterownik.h"

Sterownik::Sterownik()
{

}
